import os
from sqlalchemy import create_engine, text, inspect
from dotenv import load_dotenv

load_dotenv()
db_url = os.getenv("DATABASE_URL")
if db_url.startswith("postgres://"):
    db_url = db_url.replace("postgres://", "postgresql://", 1)

engine = create_engine(db_url)
insp = inspect(engine)
print("Tables:", insp.get_table_names())
