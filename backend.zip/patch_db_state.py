import re

with open("Proyecto_Apollo/modules/chat/state/db_state.py", "r") as f:
    content = f.read()

# 1. Add Users import
content = content.replace("from Proyecto_Apollo.models.messages import Messages\n# engine removed", 
"from Proyecto_Apollo.models.messages import Messages\nfrom Proyecto_Apollo.models.users import Users\n# engine removed")

# 2. Add local_user_id and sync method
sync_user_code = """
    local_user_id: int | None = None
    
    def sync_user_sync(self):
        \"\"\"Sincroniza el usuario de Supabase Auth con la base de datos local.\"\"\"
        if not self.user_is_authenticated or not self.user_id:
            return None
            
        try:
            with rx.session() as session:
                statement = select(Users).where(Users.supabase_uid == self.user_id)
                user = session.exec(statement).first()
                if user:
                    return user.id
                
                # Crear nuevo usuario si no existe
                new_user = Users(
                    supabase_uid=self.user_id,
                    correo=self.user_email or "",
                    nombre=self.user_metadata.get("first_name", "") if self.user_metadata else "",
                    apellido=self.user_metadata.get("last_name", "") if self.user_metadata else "",
                    fecha_de_nacimiento="N/A",
                    password_hash=""
                )
                session.add(new_user)
                session.commit()
                session.refresh(new_user)
                print(f"[DEBUG] 👤 Usuario sincronizado localmente con ID: {new_user.id}")
                return new_user.id
        except Exception as e:
            print(f"[ERROR] ❌ Error sincronizando usuario: {e}")
            return None
"""

content = content.replace("    _conversations_loaded: bool = False", "    _conversations_loaded: bool = False\n" + sync_user_code)

# 3. Update load_conversations_async to get user ID first and pass to thread
old_load_async = """        try:
            # ⭐ Ejecutar en thread separado para no bloquear
            loop = asyncio.get_event_loop()
            conversations_data = await loop.run_in_executor(
                _db_executor,
                self._load_conversations_sync
            )"""

new_load_async = """        try:
            # Sincronizar usuario antes de cargar
            if not self.local_user_id:
                self.local_user_id = self.sync_user_sync()
            
            # ⭐ Ejecutar en thread separado para no bloquear
            loop = asyncio.get_event_loop()
            conversations_data = await loop.run_in_executor(
                _db_executor,
                self._load_conversations_sync,
                self.local_user_id
            )"""

content = content.replace(old_load_async, new_load_async)

# 4. Update _load_conversations_sync signature and filter
content = content.replace("def _load_conversations_sync(self) -> list[dict]:", "def _load_conversations_sync(self, user_id: int | None = None) -> list[dict]:")
content = content.replace("statement = select(Conversations).order_by(Conversations.updated_at.desc())", """statement = select(Conversations)
                if user_id:
                    statement = statement.where(Conversations.user_id == user_id)
                statement = statement.order_by(Conversations.updated_at.desc())""")

# 5. Update create_new_conversation_async to pass user_id
old_create_async = """            conversation_id = await loop.run_in_executor(
                _db_executor,
                self._create_conversation_sync,
                thread_id,
                title
            )"""
new_create_async = """            
            if not self.local_user_id:
                self.local_user_id = self.sync_user_sync()
                
            conversation_id = await loop.run_in_executor(
                _db_executor,
                self._create_conversation_sync,
                thread_id,
                title,
                self.local_user_id
            )"""
content = content.replace(old_create_async, new_create_async)

# 6. Update _create_conversation_sync
content = content.replace("def _create_conversation_sync(self, thread_id: str, title: str) -> int | None:", "def _create_conversation_sync(self, thread_id: str, title: str, user_id: int | None = None) -> int | None:")
content = content.replace("conversation = Conversations(\n                    thread_id=thread_id,\n                    title=title\n                )", "conversation = Conversations(\n                    thread_id=thread_id,\n                    title=title,\n                    user_id=user_id\n                )")

# 7. Update create_new_conversation
content = content.replace("conversation = Conversations(\n                    thread_id=thread_id,\n                    title=title\n                )", "conversation = Conversations(\n                    thread_id=thread_id,\n                    title=title,\n                    user_id=self.local_user_id\n                )", 2) # Wait, it only matched once above, now it might match twice. I'll just use regex.

# 8. Update messages logic
old_add_msg = """            message = Messages(
                conversation_id=conversation_id,
                question=question,
                answer=answer
            )"""
new_add_msg = """            message = Messages(
                conversation_id=conversation_id,
                question_encrypted=question,
                answer_encrypted=answer
            )"""
content = content.replace(old_add_msg, new_add_msg)

old_get_msg = """                {
                    "question": msg.question, 
                    "answer": msg.answer, 
                    "created_at": msg.created_at
                } """
new_get_msg = """                {
                    "question": msg.question_encrypted, 
                    "answer": msg.answer_encrypted, 
                    "created_at": msg.created_at
                } """
content = content.replace(old_get_msg, new_get_msg)

with open("Proyecto_Apollo/modules/chat/state/db_state.py", "w") as f:
    f.write(content)
