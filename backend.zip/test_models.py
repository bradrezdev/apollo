from Proyecto_Apollo.Proyecto_Apollo import app
print("Models:", app.models)
